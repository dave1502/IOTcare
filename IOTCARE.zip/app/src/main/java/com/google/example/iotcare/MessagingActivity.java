package com.google.example.iotcare;

/**
 * Created by Administrator on 2018-02-07.
 */

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.Telephony;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;


public class MessagingActivity extends AppCompatActivity implements View.OnClickListener{

    private Button Yes;
    private Button No;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging2);
        Yes = (Button)findViewById(R.id.Yes);
        No = (Button)findViewById(R.id.No);
        Yes.setOnClickListener(this);
        No.setOnClickListener(this);
    }

    @Override
            public void onClick(View v) {
                int id=v.getId();
                switch(id){
                    case R.id.Yes:{
                        try{
                            SmsManager smgr = SmsManager.getDefault();
                            smgr.sendTextMessage("01050074765",null,"살려주세요",null,null);
                            Toast.makeText(MessagingActivity.this, "경찰서에 문자를 보냈습니다.", Toast.LENGTH_SHORT).show();
                        }
                        catch (Exception e){
                            Toast.makeText(MessagingActivity.this, "문자를 보내지 못했습니다. 권한을 확인해주세요.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    case R.id.No:{
                        Intent intent = new Intent(this,MainActivity.class);
                        startActivity(intent);
                    }
                }
            }
}