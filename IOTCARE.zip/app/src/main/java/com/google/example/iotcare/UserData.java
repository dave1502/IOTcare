package com.google.example.iotcare;

/**
 * Created by Administrator on 2018-02-13.
 */

public class UserData {
    public String userEmailID; // email 주소에서 @ 이전까지의 값.
    public String fcmToken;
}

